﻿//By using system key word it will importing namespaces specified in code
//it import Console class we need to use System key word.
//it will provided by .net framework we can reuse any time any where through out the the application.
using System;

//declaring this namespace is custom namespace with class name program
//scope of name space is control class and method
namespace ConsoleApp1
{
    //class is like blue print of type.A class can contain methods ,events and so on.
    class Program
    {
        //when we declare method as static then class programm exist in memory and can access the class it self
        //void is return type of the method if declare void as return type then we no need to return any values from method

        //Main is entry point of the application program executionm will start from main method
        static void Main(string[] args)
        {
            //Console is a class which imported from system namespace 
            //WriteLine is used to print values in console and move line to next
            Console.WriteLine("Welcome World");
            Console.WriteLine("Welcome advanced languge");
            //DateTime.Now is predefined method from .net framework it will return current datetime
            Console.WriteLine(DateTime.Now);
            Console.ReadLine();
        }
    }
}

//Output:--
//Welcome World
//Welcome advanced languge
//11/9/2021 4:13:44 PM
