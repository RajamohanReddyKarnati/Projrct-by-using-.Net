﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class AddAndRemoveUseingCollection
    {
        public static void Main()
        {
            Collection<string> orderItems = new Collection<string>();
            orderItems.Add("Department");
            orderItems.Add("Grocery");
            orderItems.Add("Food"); 
            orderItems.Add("Accessory"); 
            orderItems.Add("Pharmacies");
            orderItems.Add("Technology");
            orderItems.Add("Pets"); 
            orderItems.Add("Toy"); 
            orderItems.Add("Thrift"); 
            orderItems.Add("Services"); 
            orderItems.Add("Kiosks");
            Console.WriteLine("{0} OrderItems:", orderItems.Count);
            Display(orderItems);
            Console.WriteLine("\nIndexOf(\"Kiosks\"):{0}",orderItems.IndexOf("Kiosks"));
            Console.WriteLine("\nContains(\"Services\"):{0}", orderItems.Contains("Services"));
            Console.WriteLine("\nInsert(2,\"Specialty\")");
            orderItems.Insert(2, "Specialty");
            Display(orderItems);
            Console.WriteLine("\norderItems[2]:{0}", orderItems[2]);
            Console.WriteLine("\norderItems[2]=\"Clothing\"");
            Display(orderItems);
            Console.WriteLine("\nRemove(\"Clothing\"");
            orderItems.Remove("Clothing");
            Display(orderItems);
            Console.WriteLine("\nRemoveAt(0)");
            orderItems.RemoveAt(0);
            Display(orderItems);
            Console.WriteLine("\norderItems.Clear()");
            orderItems.Clear();
            Console.WriteLine("Count:{0}", orderItems.Count);
        }
        private static void Display(Collection<string> tList)
        {
            Console.WriteLine();
            foreach (var item in tList)
            {
                Console.WriteLine(item);
            }
        }
    }
}
